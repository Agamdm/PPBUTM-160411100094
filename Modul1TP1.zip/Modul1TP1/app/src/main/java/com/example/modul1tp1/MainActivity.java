package com.example.modul1tp1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView text1, text2;
    String coba;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void setText(View view){
        text1=(TextView)findViewById(R.id.nama);
        coba=text1.getText().toString();
        text2=(TextView)findViewById(R.id.hasil);
        text2.setText("Nama Saya adalah " + coba);
    }
}